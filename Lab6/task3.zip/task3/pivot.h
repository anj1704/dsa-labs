#ifndef PIVOT_H
#define PIVOT_H

int pivot(int Ls[], int lo, int hi);
void swap(int arr[], int low, int high);
void printArray(int arr[], int n);
int min(int a, int b);
int part(int Ls[], int lo, int hi, int pInd);

#endif
